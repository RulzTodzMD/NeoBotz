# Bot Whatsapp
## Beta Multi Device 

<p align="center">
<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQMbpnB0PY8P1Ot5I_2-01Xdnhq4xJuctJxQ&usqp=CAU" alt="Neobot-MD" width="200"/>

<p align="center">
    <a href="https://Lexxy24.github.io">
        <img
            src="https://readme-typing-svg.herokuapp.com?size=15&width=280&lines=Neobotz+By+Lexxy+Official+🙏"
            alt="Subscribe Yt Lexxy Official"
        />
    </a>
</p>

## Heroku Buildpack

Click the deploy icon below !

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Lexxy24/NEOBOT-MDV8)

```bash
 > heroku/nodejs
 > https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
 > https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```

## TERMUX USER
```bash
$ pkg update && pkg upgrade
$ pkg install mc
$ pkg install git
$ pkg install yarn
$ pkg install nodejs
$ pkg install libwebp
$ pkg install ffmpeg
$ termux-setup-storage
$ git clone https://github.com/Lexxy24/NEOBOT-MDV8
$ cd NEOBOT-MDV8
$ yarn install
$ rm -r session.json
$ npm start
```

## RDP/VPS USER
```bash 
$ git clone https://github.com/Lexxy24/NEOBOT-MDV8
$ cd NEOBOT-MDV8
$ yarn install
$ rm -r session.json
$ npm start
```

# My Sosial
- [Whatsapp](https://wa.me/6283834558105)

- [YouTube](https://youtube.com/channel/UCLd-bhT8Dqq9PjGc6bWUVyg)
- [Group](https://chat.whatsapp.com/E3zewfxrc5pKE6Rzb3BuqG)
- [Nomor Bot](https://wa.me/6283834558105)
